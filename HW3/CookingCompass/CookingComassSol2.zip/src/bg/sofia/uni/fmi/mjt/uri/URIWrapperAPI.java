package bg.sofia.uni.fmi.mjt.uri;

import java.net.URI;

public interface URIWrapperAPI {
    URI getUri();
}
