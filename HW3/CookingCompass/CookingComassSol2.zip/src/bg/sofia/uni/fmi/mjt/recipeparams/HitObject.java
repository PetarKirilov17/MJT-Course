package bg.sofia.uni.fmi.mjt.recipeparams;

public record HitObject(Recipe recipe) {
}
