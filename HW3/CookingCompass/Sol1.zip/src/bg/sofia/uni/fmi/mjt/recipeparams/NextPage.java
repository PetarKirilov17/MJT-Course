package bg.sofia.uni.fmi.mjt.recipeparams;

public record NextPage(String href, String title) {
}
