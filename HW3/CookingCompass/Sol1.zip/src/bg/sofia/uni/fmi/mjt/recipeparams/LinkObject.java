package bg.sofia.uni.fmi.mjt.recipeparams;

public record LinkObject(NextPage next) {
}
